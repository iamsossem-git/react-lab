import EventChange from "./EventChange"
import EventClick from "./EventClick"
import LoginPage from "./LoginPage"
import ToDoList from "./ToDoList"
import "./Event.css";

const Event = () => {
  return (
    <div id="event-page">
      {/* <EventClick /> */}
      {/* <EventChange /> */}
      {/* <ToDoList /> */}
      <LoginPage />
    </div>
  )
}

export default Event
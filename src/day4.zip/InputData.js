const InputData = ({title}) => {
  return (
    <div className="input-data">
      <input />
      <label>{title}</label>
    </div>
  )
}

export default InputData